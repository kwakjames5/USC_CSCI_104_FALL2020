#ifndef HASH_H
#define HASH_H
#include <string>

unsigned int calculateHash(std::string mystring);

#endif
