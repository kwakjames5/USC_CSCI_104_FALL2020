# CS 104 Student Repository

- **Name**: James Kwak
- **USC ID**: 6013516433
- **Email**: kwakjame@usc.edu

My setops_test.cpp has the union operator
test cases commented out due to my union
operator code does not work properly.

Problem 4 should be submitted via pdf
file in my github.

hw2.txt has my answers for quesions 1-3.

I had trouble working with figuring out
how to make double or triple majors work
in my majors.cpp due to there being clashes
with the input map. The rest of the program
should more or less work.