# CS 104 Student Repository

- **Name**: James Kwak
- **USC ID**: 6013516433
- **Email**: kwakjame@usc.edu

My sentences program works properly but my
sat_solver program is running into issues
that I was unable to fix before committing my code.
I will try to find my issues and come in for a regrade.