# CS 104 Student Repository

- **Name**: James Kwak
- **USC ID**: 6013516433
- **Email**: kwakjame@usc.edu

My parse function is leaving me with core dumps. 
My current parse function seems to not work
as I was hoping for, so I will likely try to 
find new ways to go about this function.

The rest of my code should be functional. Please
look there. Thanks.