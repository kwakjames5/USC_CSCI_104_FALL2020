# CS 104 Student Repository

- **Name**: James Kwak
- **USC ID**: 6013516433
- **Email**: kwakjame@usc.edu

My deque_test / G-test is not complete.
That is the reason it is not working in the Makefile.

In terms of deque.h, push_front is not working when
the capacity of my deck ever exceeds the original
deque capacity of 5. The rest of my deque.h should
work normally.

The rest of my programs (laundry, 
rem_dup (and its compartments) and stack.h)
are complete, finished and working properly.