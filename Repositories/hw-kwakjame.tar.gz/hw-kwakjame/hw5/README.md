# CS 104 Student Repository

- **Name**: James Kwak
- **USC ID**: 6013516433
- **Email**: kwakjame@usc.edu

Many of my components in twiteng.cpp from hw3
are still faulty and have bugs within the code
that I have still not fully fixed (AND search, addTweet,
parse). For this reason, many parts of hw5 that 
are included in the repository will likely not run 
properly when graded by the BOT.

I am in the process of using office hours and
regrade opportunities to get my hw3 functions
working before the final draft of this project.

The individual components of hw5, however,
should still be functional. Should the bot
not run through my code properly
due to my faulty twiteng.cpp, I will come in
for the regrade.

Thank you.